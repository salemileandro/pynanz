import yfinance as yf
import pandas as pd
from pandas import Timestamp, Timedelta


class Downloader:
    """

    """
    def __init__(self):
        pass

    def __call__(self, *args, **kwargs):
        pass