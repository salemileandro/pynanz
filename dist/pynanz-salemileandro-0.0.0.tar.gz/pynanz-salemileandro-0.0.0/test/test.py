from fintk import StockData
import datetime
import matplotlib.pyplot as plt
import numpy as np
import os
from fintk import Markowitz
from tabulate import tabulate

stock_list = ["AAPL", "USFD", "AF.PA", "GOOGL", "PFE", "BA", "AMS.SW", "SHOP"]
add_cash = True

stock = StockData()

flag = False
if flag:
    stock.download(stock_list=stock_list, add_cash=add_cash)
    stock.save("savefile")
else:
    stock.load("savefile")



model = Markowitz()
model.set_parameters(alpha=0.00,
                     risk_aversion=None,
                     sigma_target=0.25,
                     period=30)


start_date = datetime.datetime(year=2020, month=1, day=1)
end_date = datetime.datetime(year=2020, month=4, day=12)

model.solve(stock,
            start_date=start_date,
            end_date=end_date,
            delta_date=2)

print(tabulate(model.summary, headers='keys', tablefmt='psql'))


plt.plot(model.summary["capital"])
plt.xticks(rotation=90)
plt.tight_layout()
plt.show()

_ = input()